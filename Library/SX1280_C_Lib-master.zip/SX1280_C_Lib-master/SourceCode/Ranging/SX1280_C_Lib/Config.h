#ifndef __CONFIG_H__
#define __CONFIG_H__

#define DEBUG

#define NSS 10
#define NRESET 6
#define BUSY 5
#define DIO1 2
#define DIO2 3
#define DIO3 4

#endif /* CONFIG_H__ */
