# SX1280_C_Lib
A simple transmit/receive demo with E28-2G4M12S (Semtech SX1280) LoRa 2.4GHz module controlled by Arduino Nano
